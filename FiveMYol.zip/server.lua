function da ( ) 
setFarClipDistance(4000)  
setCloudsEnabled(true) 
end 
setTimer(da, 5000, 0)




----- Sitemiz : https://sparrow-mta.blogspot.com/

----- Facebook : https://facebook.com/sparrowgta/
----- İnstagram : https://instagram.com/sparrowmta/
----- YouTube : https://youtube.com/c/SparroWMTA/

----- Discord : https://discord.gg/DzgEcvy