CONST_GENERATED_SLIDERS = {
	[1] = {
		title = "« Hoş Geldin »",
		text  = [[
			Sunucuda yeni bir oyuncuysan /hediye yazarak 10.000 $ alabilirsin.
		]]
	},

	[2] = {
		title = "« Gizli Kristaller »",
		text  = [[
			Sunucuda bir kristal arama sistemi bulunuyor:
			Haritanın farklı köşelerinde kristalleri bulun ve benzersiz
			araba modifiyelerinde harcayın!
		]]
	},

	[3] = {
		title = "« Sosyal Medya Hesaplarımız »",
		text  = [[
			Sosyal Medya Hesaplarımızı takip ederek güncel bilgilere ulaşabilirsiniz.
			
			www.instagram.com/sparrowmta/
		]]
	},
}

function splitTableWithCount( tbl, count )
    local splitted = {}

    local currentBlock = 1
    local cCount = 0

    for index, value in pairs( tbl ) do

        splitted[ currentBlock ] = splitted[ currentBlock ] or {}
        table.insert( splitted[ currentBlock ], value )

        cCount = cCount + 1
        if cCount >= count then
            currentBlock = currentBlock + 1
            cCount = 0
        end
    end
    return splitted
end

function string.split( str )
    if not str or type( str ) ~= "string" then return false end

    local splitStr = {}
    for i = 1, utf8.len( str ) do
        local char = utf8.sub( str, i, i )
        table.insert( splitStr , char )
    end

    return splitStr 
end

function splitStringWithCount( str, count )
    local result = splitTableWithCount( string.split( str ), count )

    local _str = {}

    for _, row in pairs( result ) do
        table.insert( _str, table.concat( row, '' ) )
    end

    return _str
end

function Clamp( min, a, max )
    return math.max( math.min( a, max ), min );
end

-- Sitemiz : https://sparrow-mta.blogspot.com/

-- Facebook : https://facebook.com/sparrowgta/
-- İnstagram : https://instagram.com/sparrowmta/
-- YouTube : https://www.youtube.com/@TurkishSparroW/

-- Discord : https://discord.gg/DzgEcvy