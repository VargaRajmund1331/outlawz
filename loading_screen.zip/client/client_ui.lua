-- Объявляем функцию ДО её использования
function math.lerp( a, b, k )
	local result = a * ( 1 - k ) + b * k
	if result >= b then
		result = b
	elseif result <= a then
		result = a
	end
	return result
end

-- Функция для адаптации размеров под разные разрешения
function adaptSize( size )
    return size * math.min(scx / 1920, scy / 1080) -- используем минимальный масштаб для сохранения пропорций
end

-- Функция для адаптации позиции
function adaptPosition( x, y )
    return x * (scx / 1920), y * (scy / 1080)
end

-- Переменные для управления загрузочным экраном
local isLoadingScreenActive = false
local lastDownloaded = nil
local lastTime = nil
local speed = 0

-- Функция для запуска загрузочного экрана
function startLoadingScreen()
    if isLoadingScreenActive then return end
    
    isLoadingScreenActive = true
    
    
end

-- Функция для остановки загрузочного экрана
function stopLoadingScreen()
    if not isLoadingScreenActive then return end
    
    isLoadingScreenActive = false
    
    
   
end

-- Обработчик события загрузки
addEventHandler( "onClientTransferBoxProgressChange", root, function( downloadedSize, totalSize )
    -- Если загрузочный экран еще не активен, запускаем его
    if not isLoadingScreenActive then
        startLoadingScreen()
    end
    
    -- Инициализация переменных при первом вызове
    if not lastDownloaded then
        lastDownloaded = downloadedSize / 1024 / 1024
        lastTime = getTickCount()
        speed = 0
        return
    end

    -- Расчет реальной скорости скачивания
    local currentTime = getTickCount()
    local timeDiff = (currentTime - lastTime) / 1000 -- время в секундах
    
    if timeDiff > 0 then
        local currentDownloaded = downloadedSize / 1024 / 1024
        local downloadedDiff = currentDownloaded - lastDownloaded -- разница в МБ
        speed = downloadedDiff / timeDiff -- скорость в МБ/сек
        
        -- Ограничиваем скорость для красивого отображения
        speed = math.max(0, math.min(speed, 1000))
    end
    
    -- Обновляем переменные для следующего расчета
    lastDownloaded = downloadedSize / 1024 / 1024
    lastTime = currentTime

	local downloaded = string.format( "%.2f", downloadedSize / 1024 / 1024 ) or 0
	local total = string.format( "%.2f", totalSize / 1024 / 1024 ) or 0

	dxDrawImage( 0, 0, scx, scy, "files/img/bg.png" )

	-- Адаптируем все размеры и позиции
	local titleX, titleY = adaptPosition(110, 35)
	local circleX, circleY = adaptPosition(55, 40)
	local circleSize = adaptSize(48)
	
	-- Заголовок
	dxDrawText( "Güncellemeler İndiriliyor...", titleX, titleY, 0, 0, _, fonts.m_15 )

	-- Круг прогресса
	dxDrawImage( circleX, circleY, circleSize, circleSize, circle_tex, tocolor( 255, 255, 255, 100 ) )

	local progressValue = (tonumber(downloaded) or 1) / (tonumber(total) or 1)
	dxSetShaderValue( CIRCLE_SHADER, "dg", math.lerp( 0, 2, progressValue ) )
	dxDrawImage( circleX, circleY, circleSize, circleSize, CIRCLE_SHADER )

	-- Процент в круге
	local percentage = ( math.floor( progressValue * 100 ) or "100" ) .. "%"
	dxDrawText( percentage, circleX, circleY, circleX + circleSize, circleY + circleSize, _, fonts.m_10, "center", "center" )

	-- Прогресс в МБ
	local progress_mb = math.floor( downloaded ) .. " / " .. math.floor( total ) .. " МB"
	local progressTextX, progressTextY = adaptPosition(110, 65)
	dxDrawText( progress_mb, progressTextX, progressTextY, 0, 0, _, fonts.m_10 )

	-- Скорость скачивания
	local twidth = dxGetTextWidth( progress_mb, 1, fonts.m_10 )
	local speedIconX = progressTextX + twidth + adaptSize(10)
	local speedIconY = progressTextY + adaptSize(5)
	dxDrawImage( speedIconX, speedIconY, adaptSize(16), adaptSize(12), "files/img/speedicon.png" )
	
	local speedTextX = speedIconX + adaptSize(25)
	local speedTextY = progressTextY
	dxDrawText( string.format( "%.2f", speed ) .. " МB/sn", speedTextX, speedTextY, 0, 0, tocolor( 155, 155, 155, 200 ), fonts.m_10 )

	-- Кнопки навигации
	local buttonY = scy - adaptSize(80)
	local buttonX = adaptSize(55)
	local buttonSize = adaptSize(24)
	
	dxDrawImage( buttonX, buttonY, buttonSize, buttonSize, "files/img/prevButton.png" )
	dxDrawText( "Önceki İpucu", buttonX + adaptSize(30), buttonY + adaptSize(2), 0, 0, _, fonts.m_13 )

	local prevTextWidth = dxGetTextWidth( "Önceki İpucu", 1, fonts.m_13 )
	local nextButtonX = buttonX + adaptSize(30) + prevTextWidth + adaptSize(15)
	dxDrawImage( nextButtonX, buttonY, buttonSize, buttonSize, "files/img/nextButton.png" )
	dxDrawText( "Sonraki İpucu", nextButtonX + adaptSize(30), buttonY + adaptSize(2), 0, 0, _, fonts.m_13 )

	-- Советы
	local data = CONST_GENERATED_SLIDERS[ current_index ]
	if data then
		local maxChars = math.floor(75 * (scx / 1920))
		local message_splitted = splitStringWithCount( data.text, maxChars )
		local textHeight = #message_splitted * dxGetFontHeight( 1, fonts.m_11 )
		
		-- Текст совета
		local tipTextY = buttonY - textHeight - adaptSize(60)
		dxDrawText( data.text, buttonX, tipTextY, 0, 0, tocolor( 155, 155, 155 ), fonts.m_11 )

		-- Индикаторы прогресса
		local indicatorWidth = adaptSize(127)
		local indicatorSpacing = adaptSize(133)
		local indicatorsY = buttonY - adaptSize(140)
		
		for i = 1, #CONST_GENERATED_SLIDERS do
			local indicatorX = buttonX + (indicatorSpacing * (i - 1))
			dxDrawRectangle( indicatorX, indicatorsY, indicatorWidth, adaptSize(2), tocolor( 155, 155, 155, 100 ), true )
			if current_index == i then
				dxDrawRectangle( indicatorX, indicatorsY, indicatorWidth, adaptSize(2), _, true )
			end
		end

		-- Заголовок совета
		local titleY = buttonY - adaptSize(200)
		dxDrawText( data.title, buttonX, titleY, 0, 0, tocolor( 255, 255, 255 ), fonts.b_20 )
	end
	
	-- Если загрузка завершена (100%), останавливаем загрузочный экран через 1 секунду
	if progressValue >= 1 then
		setTimer(stopLoadingScreen, 1000, 1)
	end
end)

-- Бинды для навигации по советам (они должны работать даже при заблокированном управлении)
bindKey( "q", "down", function() 
    if isLoadingScreenActive then
        current_index = math.max( 1, current_index - 1 )
    end
end)

bindKey( "e", "down", function() 
    if isLoadingScreenActive then
        current_index = math.min( #CONST_GENERATED_SLIDERS, current_index + 1 )
    end
end)


-- Также запускаем при старте ресурса
addEventHandler("onClientResourceStart", resourceRoot, function()
    outputDebugString("Loading Screen Scripti Aktif..")
    if localPlayer and not isLoadingScreenActive then
        setTimer(function()
            startLoadingScreen()
        end, 1000, 1)
    end
end)

-- Sitemiz : https://sparrow-mta.blogspot.com/

-- Facebook : https://facebook.com/sparrowgta/
-- İnstagram : https://instagram.com/sparrowmta/
-- YouTube : https://www.youtube.com/@TurkishSparroW/

-- Discord : https://discord.gg/DzgEcvy