scx, scy = guiGetScreenSize()
COLOR_WHITE = 0xFFFFFFFF

CIRCLE_SHADER = dxCreateShader( [[
	texture tex;
	float dg = 0;
	float angle = 1;
	float4 rgba = float4(255,255,255,255);
	float4 urgba = float4(0,0,0,0);

	sampler Sampler0 = sampler_state
	{
	    Texture = (tex);
	};

	float4 PixelShaderFunction(float2 coords: TEXCOORD0) : COLOR0   
	{
	    float4 color = tex2D(Sampler0,coords);
	    clip(color.a);
	    float dx = coords.x - 0.5f;
	    float dy = coords.y - 0.5f;
	    float degree = -180 + dg*180;
	    clip((radians(degree) - atan2(dy,dx))*angle);
	    return color *= rgba/255;
	}
	 
	technique radarcircle
	{
	    pass Pass0
	    {
	        PixelShader = compile ps_2_0 PixelShaderFunction();
	    }
	} 

]] )

local function font( name, size )
	return dxCreateFont( "files/fonts/Gilroy-" .. name .. ".ttf", size, false, "cleartype" )
end

fonts = {
	m_15 = font( "Medium", 15 ),
	m_10 = font( "Bold", 10 ),
	b_12 = font( "Bold", 12 ),
	m_13 = font( "Medium", 13 ),
	m_11 = font( "Medium", 11 ),
	b_20 = font( "Bold", 20 ),
}

circle_tex = dxCreateTexture( "files/img/circle.png" )

dxSetShaderValue( CIRCLE_SHADER, "tex", circle_tex )

_dxDrawImage = dxDrawImage
function dxDrawImage( x, y, sx, sy, tex, color )
	_dxDrawImage( x, y, sx, sy, tex, 0, 0, 0, color, true )
end

_dxDrawText = dxDrawText
function dxDrawText( text, x, y, sx, sy, color, font, al_x, al_y )
	_dxDrawText( text, x, y, sx, sy, color, 1, font, al_x, al_y, false, false, true )
end

current_index = 1

-- Sitemiz : https://sparrow-mta.blogspot.com/

-- Facebook : https://facebook.com/sparrowgta/
-- İnstagram : https://instagram.com/sparrowmta/
-- YouTube : https://www.youtube.com/@TurkishSparroW/

-- Discord : https://discord.gg/DzgEcvy