
    
    txd = engineLoadTXD ( "object.txd" )
	col = engineLoadCOL ( "object.col" )
    dff = engineLoadDFF ( "object.dff" )
	
    engineImportTXD ( txd, 5853  )
    engineReplaceCOL ( col, 5853  )
    engineReplaceModel ( dff, 5853  )

    setOcclusionsEnabled ( false )

getResourceName(getThisResource(), true, 698718680); if true then return end


--- Sitemiz : https://sparrow-mta.blogspot.com/

--- Facebook : https://facebook.com/sparrowgta/
--- İnstagram : https://instagram.com/sparrowmta/
--- YouTube : https://www.youtube.com/@TurkishSparroW/

--- Discord : https://discord.gg/DzgEcvy